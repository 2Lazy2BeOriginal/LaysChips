# Just click the Play button on top right then hide this window and quickly switch to the Mynintendo
# Redeem a point code tab and let the magic begin. Make sure the textbox is empty
import time
import json
import random
import string
from selenium import webdriver
from selenium.webdriver.support.ui import Select
# hover over selenium and click alt+shift+enter to install the package

# adjust the HowMany variable to how many codes u want. I suggest 50
HowMany = 2
# type True if u want only want codes or False if you already have code and just want to input code
# If you want to get codes and enter to mynintendo then set both variables to True
GetCode = True
EnterCode = True
EMAIL = 'mynintendowinner@gmail.com'
PASSWORD = 'IHNBrOClF2'
Folder = r'C:\Users\manny\Downloads\Lays\GetCode'
CodeList = []


# the codes.txt file is there just for prexisting code
text = open(Folder + '\codes.txt')
for code in text:
    CodeList.append(code)

names = json.loads(open(Folder + '\\names.json').read())

def Start():
    # once opened it will fill in the confirm your age
    Day = Select(web.find_element_by_xpath('//*[@id="bday_day"]'))
    Day.select_by_index(2)
    Month = Select(web.find_element_by_xpath('//*[@id="bday_month"]'))
    Month.select_by_index(4)
    Month = Select(web.find_element_by_xpath('//*[@id="bday_year"]'))
    Month.select_by_index(24)
    Prov = Select(web.find_element_by_xpath('//*[@id="province"]'))
    Prov.select_by_index(5)
    Button = web.find_element_by_xpath('//*[@id="popup-subscribe"]/button')
    Button.click()

# fill in the textboxes

def getcode(fake):
    code = '3083090011120:33'
    codeBox = web.find_element_by_xpath('//*[@id="contest-upccode"]')
    codeBox.send_keys(code)

    email = fake
    emailBox = web.find_element_by_xpath('//*[@id="contest-email"]')
    emailBox.send_keys(email)

    First = "gdfgd"
    FirstBox = web.find_element_by_xpath('//*[@id="contest-firstname"]')
    FirstBox.send_keys(First)

    Last = "sfsdf"
    LastBox = web.find_element_by_xpath('//*[@id="contest-lastname"]')
    LastBox.send_keys(Last)

    Zip = "V3Z3V7"
    ZipBox = web.find_element_by_xpath('//*[@id="postalcode"]')
    ZipBox.send_keys(Zip)

    Confirm = web.find_element_by_xpath('//*[@id="contestsignup-form"]/div[6]/div/label')
    Confirm.click()

    # there is 2 xpath with the same xpath so we have to do this to get the 2nd time this xpath occurs
    all_province = web.find_elements_by_xpath('//*[@id="province"]')
    second_province = all_province[1]

    Prov = Select(second_province)
    Prov.select_by_index(5)

    Button = web.find_element_by_xpath('//*[@id="submitcontest"]')
    Button.click()

def CopyCode():
    code = web.find_element_by_xpath('/html/body/div[2]/div[1]/section/div/section/div/div/span')
    CodeList.append(code.text)
    print(code.text)

def FakeEmail():
    # pick a random names and add 4 random numbers. chose yahoo because who uses yahoo?
    name = random.choice(names)
    name_extra = ''.join(random.choice(string.digits) for i in range (4))
    email = name.lower() + name_extra +'@yahoo.com'
    return email

def sendemail():
    time.sleep(1)
    login = web.find_element_by_xpath('/html/body/div/div[1]/div[1]/form/button')
    login.click()
    email = web.find_element_by_xpath('//*[@id="login-form-id"]')
    email.send_keys(EMAIL)
    password = web.find_element_by_xpath('//*[@id="login-form-password"]')
    password.send_keys(PASSWORD)
    enter = web.find_element_by_xpath('//*[@id="login-form"]/div[2]/div[2]')
    enter.click()
    # this pauses the bot until we get past the I am not a bot section and verification
    cango = input("press enter and it will allow you to go")
    print("the bot has resumed")
    time.sleep(1)
    web.get('https://my.nintendo.com/serial_number')


def SendCode():
    time.sleep(1)
    for each_line in CodeList:
        # go to the textbox, double clicks and enters the code in here then submits it.
        input = web.find_element_by_class_name('SerialNumberAction_input')
        input.send_keys(each_line)
        # go to submit
        redeem = web.find_element_by_xpath('/html/body/div/div[2]/section/div/div[3]/div/button')
        redeem.click()
        time.sleep(2)
        try:
            # if the code is valid it will redeem it then wait 2 seconds because computers are not fast
            # go to the redeem button
            ok = web.find_element_by_xpath('/html/body/div/div[5]/div/div/div[3]/div/button')
            ok.click()
            time.sleep(2)
        except:
            # if the code is invalid it just skips and tries the next code
            continue


if GetCode:
    # This opens up the website
    web = webdriver.Chrome(Folder + '\chromedriver.exe')
    web.get('https://www.tastyrewards.com/en-ca/contest/fritolaycontest/participate')
    # have to go through select your birthday
    Start()
    # 2 seconds is enough for the website to load
    time.sleep(2)
    try:
        for i in range(HowMany):
            fake = FakeEmail()
            getcode(fake)
            time.sleep(1)
            CopyCode()
            time.sleep(1)
            web.back()
            time.sleep(1)
        web.close()
    except:
        web.close()
        print("error click run again")
    time.sleep(1)
# If the user set EnterCode to true then it will enter code for you
if EnterCode:
    web = webdriver.Chrome(Folder + '\chromedriver.exe')
    web.get('https://my.nintendo.com/serial_number')
    sendemail()
    SendCode()
    web.close()










