import requests

# url = 'https://www.tastyrewards.com/en-ca/contest/fritolaycontest/participate'
test = requests.get('https://www.tastyrewards.com/en-ca/contest/fritolaycontest/participate')
data = {

}
print(test)
#requests.post(url,data=data)