# you have to Alt+shift+Enter to install pyautogui
import time
import pyautogui

# Just click the Play button on top right then hide this window and quickly switch to the Mynintendo
# Redeem a point code tab and let the magic begin. Make sure the textbox is empty

# gives you time to miniamize this tab
time.sleep(3)
textbox = pyautogui.locateCenterOnScreen("textbox.PNG")
def SendCode():
    rounds = 0
    time.sleep(1)
    text = open('code.txt')
    for each_line in text:
        # double clicking and enters the code in here then submits it.
        pyautogui.click(textbox)
        pyautogui.click(textbox)
        pyautogui.typewrite(each_line)
        pyautogui.click("submit.PNG")
        time.sleep(2)
        try:
            # if the code is valid it will redeem it then wait 2 seconds because computers are not fast
            pyautogui.click("redeem.PNG")
            time.sleep(2)
        except:
            continue
        rounds += 1
        # this just tells you in case of an error, how many codes it redeemed. so go to code.txt and remove
        # x number of lines. ex: if rounds = 5 then remove the first 5 lines
        print(rounds)
SendCode()

