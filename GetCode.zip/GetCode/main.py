# Just click the Play button on top right then hide this window and quickly switch to the Mynintendo
# Redeem a point code tab and let the magic begin. Make sure the textbox is empty
import time
import json
import random
import string
import pyautogui
from selenium import webdriver
from selenium.webdriver.support.ui import Select
# hover over pyautogui and selenium and click alt+shift+enter to install the package

# adjust the HowMany variable to how many codes u want. I suggest 50
HowMany = 0

CodeList = []
# the codes.txt file is there just for prexisting code
text = open('codes.txt')
for code in text:
    CodeList.append(code)

names = json.loads(open('names.json').read())

W, H = pyautogui.size()
# something about scale factor. basically moving the mouse to the same spot relative to screen size
scaleY = 768 / H

# This opens up the website
web = webdriver.Chrome()
web.get('https://www.tastyrewards.com/en-ca/contest/fritolaycontest/participate')

def Start():
    # once opened it will fill in the confirm your age
    Day = Select(web.find_element_by_xpath('//*[@id="bday_day"]'))
    Day.select_by_index(2)
    Month = Select(web.find_element_by_xpath('//*[@id="bday_month"]'))
    Month.select_by_index(4)
    Month = Select(web.find_element_by_xpath('//*[@id="bday_year"]'))
    Month.select_by_index(24)
    Prov = Select(web.find_element_by_xpath('//*[@id="province"]'))
    Prov.select_by_index(5)
    Button = web.find_element_by_xpath('//*[@id="popup-subscribe"]/button')
    Button.click()

# fill in the textboxes

def getcode(fake):
    code = '3083090011120:33'
    codeBox = web.find_element_by_xpath('//*[@id="contest-upccode"]')
    codeBox.send_keys(code)

    email = fake
    emailBox = web.find_element_by_xpath('//*[@id="contest-email"]')
    emailBox.send_keys(email)

    First = "gdfgd"
    FirstBox = web.find_element_by_xpath('//*[@id="contest-firstname"]')
    FirstBox.send_keys(First)

    Last = "sfsdf"
    LastBox = web.find_element_by_xpath('//*[@id="contest-lastname"]')
    LastBox.send_keys(Last)

    Zip = "V3Z3V7"
    ZipBox = web.find_element_by_xpath('//*[@id="postalcode"]')
    ZipBox.send_keys(Zip)

    Confirm = web.find_element_by_xpath('//*[@id="contestsignup-form"]/div[6]/div/label')
    Confirm.click()

    # there is 2 xpath with the same xpath so we have to do this to get the 2nd time this xpath occurs
    all_province = web.find_elements_by_xpath('//*[@id="province"]')
    second_province = all_province[1]

    Prov = Select(second_province)
    Prov.select_by_index(5)

    Button = web.find_element_by_xpath('//*[@id="submitcontest"]')
    Button.click()

def CopyCode():
    code = web.find_element_by_xpath('/html/body/div[2]/div[1]/section/div/section/div/div/span')
    CodeList.append(code.text)

def FakeEmail():
    # pick a random names and add 4 random numbers. chose yahoo because who uses yahoo?
    name = random.choice(names)
    name_extra = ''.join(random.choice(string.digits) for i in range (4))
    email = name.lower() + name_extra +'@yahoo.com'
    return email

def SendCode():
    rounds = 0
    time.sleep(1)
    for each_line in CodeList:
        # go to the textbox, double clicks and enters the code in here then submits it.
        pyautogui.moveTo((W / 2), (H / 2))
        pyautogui.click()
        pyautogui.click()
        pyautogui.typewrite(each_line)
        # go to submit
        pyautogui.moveTo((W / 2), (H / 2 + 140 * scaleY))
        pyautogui.click()
        time.sleep(2)
        try:
            # if the code is valid it will redeem it then wait 2 seconds because computers are not fast
            # go to the redeem button
            pyautogui.moveTo((W / 2), (H / 2 + 185 * scaleY))
            pyautogui.click()
            time.sleep(2)
        except:
            # if the code is invalid it just skips and tries the next code
            continue
        rounds += 1
        # this just tells you in case of an error, how many codes it redeemed. so go to code.txt and remove
        # x number of lines. ex: if rounds = 5 then remove the first 5 lines
        print(rounds)

# have to go through select your birthday
Start()
# 2 seconds is enough for the website to load
time.sleep(2)
try:
    for i in range(HowMany):
        fake = FakeEmail()
        getcode(fake)
        time.sleep(1)
        CopyCode()
        time.sleep(1)
        web.back()
        time.sleep(1)
    web.close()
except:
    web.close()
    print("error click run again")
time.sleep(1)
SendCode()







